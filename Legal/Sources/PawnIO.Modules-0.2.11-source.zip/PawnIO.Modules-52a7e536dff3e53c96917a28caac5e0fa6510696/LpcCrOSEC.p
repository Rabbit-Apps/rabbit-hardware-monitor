//  PawnIO Modules - Modules for various hardware to be used with PawnIO.
//  Copyright (C) 2025  Steve-Tech <me@stevetech.au>
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Lesser General Public
//  License as published by the Free Software Foundation; either
//  version 2.1 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//  Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public
//  License along with this library; if not, write to the Free Software
//  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

#include <pawnio.inc>

// Many parts of this was ported from the Chromium OS EC codebase.
// See https://chromium.googlesource.com/chromiumos/platform/ec/

/* I/O addresses for host command */
#define EC_LPC_ADDR_HOST_DATA 0x200
#define EC_LPC_ADDR_HOST_CMD 0x204

/* I/O addresses for host command args and params */
/* Protocol version 3 */
#define EC_LPC_ADDR_HOST_PACKET 0x800 /* Offset of version 3 packet */
#define EC_LPC_HOST_PACKET_SIZE 0x100 /* Max size of version 3 packet */

#define EC_HOST_CMD_REGION0       0x800
#define EC_HOST_CMD_MEC_REGION_SIZE 0x8

// 0x900 is the default, 0xE00 is used by AMD Framework Laptops
#define EC_LPC_ADDR_MEMMAP 0x900
#define EC_LPC_ADDR_MEMMAP_FWAMD 0xE00
// Address of the MEC memmap when accessed over the EMI
#define EC_MEC_ADDR_MEMMAP 0x100
#define EC_MEMMAP_SIZE 255 /* ACPI IO buffer max is 255 bytes */
#define EC_MEMMAP_TEXT_MAX 8 /* Size of a string in the memory map */

/* LPC command status byte masks */
/* EC has written a byte in the data register and host hasn't read it yet */
#define EC_LPC_STATUS_TO_HOST 0x01
/* Host has written a command/data byte and the EC hasn't read it yet */
#define EC_LPC_STATUS_FROM_HOST 0x02
/* EC is processing a command */
#define EC_LPC_STATUS_PROCESSING 0x04
/* Last write to EC was a command, not data */
#define EC_LPC_STATUS_LAST_CMD 0x08
/* EC is in burst mode */
#define EC_LPC_STATUS_BURST_MODE 0x10
/* SCI event is pending (requesting SCI query) */
#define EC_LPC_STATUS_SCI_PENDING 0x20
/* SMI event is pending (requesting SMI query) */
#define EC_LPC_STATUS_SMI_PENDING 0x40
/* (reserved) */
#define EC_LPC_STATUS_RESERVED 0x80

/*
 * EC is busy.  This covers both the EC processing a command, and the host has
 * written a new command but the EC hasn't picked it up yet.
 */
#define EC_LPC_STATUS_BUSY_MASK \
    (EC_LPC_STATUS_FROM_HOST | EC_LPC_STATUS_PROCESSING)

/*
 * Value written to legacy command port / prefix byte to indicate protocol
 * 3+ structs are being used.  Usage is bus-dependent.
 */
#define EC_COMMAND_PROTOCOL_3 0xda

#define EC_HOST_REQUEST_VERSION 3

#define EC_HOST_RESPONSE_VERSION 3

#define MEC_ACCESS_TYPE_BYTE 0x00
#define MEC_ACCESS_TYPE_WORD 0x01
#define MEC_ACCESS_TYPE_LONG 0x02
#define MEC_ACCESS_TYPE_LONG_AUTOINCREMENT 0x03

#define MEC_EMI_EC_ADDRESS_B0 (EC_HOST_CMD_REGION0 + 0x02)
#define MEC_EMI_EC_ADDRESS_B1 (EC_HOST_CMD_REGION0 + 0x03)
#define MEC_EMI_EC_DATA_B0 (EC_HOST_CMD_REGION0 + 0x04)
#define MEC_EMI_EC_DATA_B1 (EC_HOST_CMD_REGION0 + 0x05)
#define MEC_EMI_EC_DATA_B2 (EC_HOST_CMD_REGION0 + 0x06)
#define MEC_EMI_EC_DATA_B3 (EC_HOST_CMD_REGION0 + 0x07)

#define EC_MEMMAP_ID 0x20 /* 0x20 == 'E', 0x21 == 'C' */

#define EC_MEMMAP_HOST_CMD_FLAGS 0x27 /* Host cmd interface flags (8 bits) */

/* Host command interface supports version 3 protocol */
#define EC_HOST_CMD_FLAG_VERSION_3 0x02

#define INITIAL_UDELAY 5 /* 5 us */
#define MAXIMUM_UDELAY 10000 /* 10 ms */


new memmap_addr;
new is_mec = false;

new ec_command_proto;

Void:mec_transfer(address, data_size, write, data[]) {
    new pos = 0;

    /* Unaligned start address */
    new unaligned_offset = address % 4;
    if (unaligned_offset > 0) {
        io_out_word(MEC_EMI_EC_ADDRESS_B0, (address & 0xFFFC) | MEC_ACCESS_TYPE_BYTE);
        for (new i = unaligned_offset; i < min(unaligned_offset + data_size, 4); i++) {
            if (write) {
                io_out_byte(MEC_EMI_EC_DATA_B0 + i, data[pos++]);
            } else {
                data[pos++] = io_in_byte(MEC_EMI_EC_DATA_B0 + i);
            }
        }
        address += pos;
    }

    /* Aligned addresses */
    if (data_size - pos >= 4) {
        io_out_word(MEC_EMI_EC_ADDRESS_B0, (address & 0xFFFC) | MEC_ACCESS_TYPE_LONG_AUTOINCREMENT);
        while (data_size - pos >= 4) {
            for (new i = 0; i < 4; i++) {
                if (write) {
                    io_out_byte(MEC_EMI_EC_DATA_B0 + i, data[pos++]);
                } else {
                    data[pos++] = io_in_byte(MEC_EMI_EC_DATA_B0 + i);
                }
            }
            address += 4;
        }
    }

    /* Unaligned end address */
    if (data_size - pos > 0) {
        io_out_word(MEC_EMI_EC_ADDRESS_B0, (address & 0xFFFC) | MEC_ACCESS_TYPE_BYTE);
        for (new i = 0; i < (data_size - pos); i++) {
            if (write) {
                io_out_byte(MEC_EMI_EC_DATA_B0 + i, data[pos + i]);
            } else {
                data[pos + i] = io_in_byte(MEC_EMI_EC_DATA_B0 + i);
            }
        }
    }
}

Void:ec_transfer(address, data_size, write, data[]) {
    if (is_mec) {
        mec_transfer(address, data_size, write, data);
    } else {
        for (new i = 0; i < data_size; i++) {
            if (write) {
                io_out_byte(EC_LPC_ADDR_HOST_PACKET + address + i, data[i]);
            } else {
                data[i] = io_in_byte(EC_LPC_ADDR_HOST_PACKET + address + i);
            }
        }
    }
}

NTSTATUS:wait_for_ec(const status_addr, const timeout_usec) {
	new delay = INITIAL_UDELAY;

	for (new i = 0; i < timeout_usec; i += delay) {
		if (!(io_in_byte(status_addr) & EC_LPC_STATUS_BUSY_MASK))
			return STATUS_SUCCESS;

		microsleep2(min(delay, timeout_usec - i));

		/* Increase the delay interval after a few rapid checks */
		if (i > 20)
			delay = min(delay * 2, MAXIMUM_UDELAY);
	}
	return STATUS_TIMEOUT; /* Timeout */
}

NTSTATUS:ec_command_lpc_3(command, version, ec_out_data[EC_LPC_HOST_PACKET_SIZE], ec_out_size, ec_in_data[EC_LPC_HOST_PACKET_SIZE], ec_in_size, &result) {
    new csum = 0;
    const rq_size = 1 + 1 + 2 + 1 + 1 + 2;
    const rs_size = 1 + 1 + 2 + 2 + 2;

    /* Fail if we're going to overrun the EC */
    if (ec_out_size + rq_size > EC_LPC_HOST_PACKET_SIZE ||
        ec_in_size + rs_size > EC_LPC_HOST_PACKET_SIZE)
        return STATUS_BUFFER_TOO_SMALL;

    // struct_version, checksum, command (16bit), command_version, reserved, data_len (16bit)
    new request[rq_size] = [];
    request[0] = EC_HOST_REQUEST_VERSION;
    request[1] = csum;
    request[2] = command & 0xff;
    request[3] = command >>> 8;
    request[4] = version;
    request[5] = 0;
    request[6] = ec_out_size & 0xff;
    request[7] = ec_out_size >>> 8;

    /* Copy data and start checksum */
    ec_transfer(rq_size, ec_out_size, true, ec_out_data);
    for (new i = 0; i < ec_out_size; i++) {
        csum += ec_out_data[i] & 0xff;
    }

    /* Finish checksum */
    for (new i = 0; i < rq_size; i++)
        csum += request[i] & 0xff;

    /* Write checksum field so the entire packet sums to 0 */
    request[1] = (-csum) & 0xff;

    /* Copy header */
    ec_transfer(0, rq_size, true, request);

    /* Start the command */
    io_out_byte(EC_LPC_ADDR_HOST_CMD, EC_COMMAND_PROTOCOL_3);

    if (wait_for_ec(EC_LPC_ADDR_HOST_CMD, 1000000)) {
        debug_print(''Timeout waiting for EC response\n'');
        return STATUS_TIMEOUT;
    }

    /* Check result */
    new res = io_in_byte(EC_LPC_ADDR_HOST_DATA);
    /* First cell is negative for error */
    result = -res;
    if (res) {
        debug_print(''EC returned error result code %d\n'', res);
        /*  I would like to return STATUS_IO_DEVICE_ERROR here,
            but I still want to transfer the EC's error code. */
        return STATUS_SUCCESS;
    }

    /* Read back response header and start checksum */
    csum = 0;
    // struct_version, checksum, result, data_len, reserved
    new data_out[rs_size];
    ec_transfer(0, rs_size, false, data_out);
    for (new i = 0; i < rs_size; i++) {
        csum += data_out[i];
    }

    if (data_out[0] != EC_HOST_RESPONSE_VERSION) {
        debug_print(''EC response version mismatch\n'');
        return STATUS_DEVICE_PROTOCOL_ERROR;
    }

    if (data_out[6] || data_out[7]) {
        debug_print(''EC response reserved != 0\n'');
        return STATUS_DEVICE_PROTOCOL_ERROR;
    }

    new data_len = data_out[4] | data_out[5] << 8;
    /* First cell is positive for EC length */
    result = data_len;
    if (data_len > ec_in_size) {
        debug_print(''EC returned too much data\n'');
        return STATUS_BUFFER_TOO_SMALL;
    }

    /* Read back data and update checksum */
    ec_transfer(rs_size, data_len, false, ec_in_data);
    for (new i = 0; i < data_len; i++) {
        csum += ec_in_data[i];
    }

    /* Verify checksum */
    if (csum & 0xff) {
        debug_print(''EC response has invalid checksum\n'');
        return STATUS_CRC_ERROR;
    }

    return STATUS_SUCCESS;
}

NTSTATUS:ec_readmem_lpc(offset, bytes, dest[EC_MEMMAP_SIZE]) {
    if ((offset + bytes) > EC_MEMMAP_SIZE)
        return STATUS_INVALID_PARAMETER;

    if (is_mec) {
        mec_transfer(memmap_addr + offset, bytes, false, dest);
    } else {
        for (new i = 0; i < bytes; i++)
            dest[i] = io_in_byte(memmap_addr + offset + i);
    }

    return STATUS_SUCCESS;
}

NTSTATUS:comm_init_lpc() {
    new byte = 0xff;

    /*
     * Test if the I/O port has been configured for Chromium EC LPC
     * interface.  Chromium EC guarantees that at least one status bit will
     * be 0, so if the command and data bytes are both 0xff, very likely
     * that Chromium EC is not present.  See crosbug.com/p/10963.
     */
    byte &= io_in_byte(EC_LPC_ADDR_HOST_CMD);
    byte &= io_in_byte(EC_LPC_ADDR_HOST_DATA);
    if (byte == 0xff) {
        debug_print(''EC status register is not valid.\n'');
        return STATUS_NOT_SUPPORTED;
    }

    /*
     * Test if LPC command args are supported.
     *
     * The cheapest way to do this is by looking for the memory-mapped
     * flag.  This is faster than sending a new-style 'hello' command and
     * seeing whether the EC sets the EC_HOST_ARGS_FLAG_FROM_HOST flag
     * in args when it responds.
     */
    if (io_in_byte(EC_LPC_ADDR_MEMMAP + EC_MEMMAP_ID) == 'E' &&
        io_in_byte(EC_LPC_ADDR_MEMMAP + EC_MEMMAP_ID + 1) == 'C') {
        memmap_addr = EC_LPC_ADDR_MEMMAP;
    }
    if (io_in_byte(EC_LPC_ADDR_MEMMAP_FWAMD + EC_MEMMAP_ID) == 'E' &&
        io_in_byte(EC_LPC_ADDR_MEMMAP_FWAMD + EC_MEMMAP_ID + 1) == 'C') {
        memmap_addr = EC_LPC_ADDR_MEMMAP_FWAMD;
    }
    if (!memmap_addr) {
        /* Probe for an MEC EC */
        io_out_word(MEC_EMI_EC_ADDRESS_B0, ((EC_MEC_ADDR_MEMMAP + EC_MEMMAP_ID) & 0xFFFC) | MEC_ACCESS_TYPE_WORD);
        if (io_in_byte(MEC_EMI_EC_DATA_B0) == 'E' &&
            io_in_byte(MEC_EMI_EC_DATA_B1) == 'C') {
            is_mec = true;
            memmap_addr = EC_MEC_ADDR_MEMMAP;
        } else {
            debug_print(''Cannot find EC memmap.\n'');
            return STATUS_NOT_SUPPORTED;
        }
    }

    /* Check which command version we'll use */
    new version;
    if (is_mec) {
        io_out_word(MEC_EMI_EC_ADDRESS_B0, ((memmap_addr + EC_MEMMAP_HOST_CMD_FLAGS) & 0xFFFC) | MEC_ACCESS_TYPE_BYTE);
        version = io_in_byte(MEC_EMI_EC_DATA_B0 + (EC_MEMMAP_HOST_CMD_FLAGS % 4));
    } else {
        version = io_in_byte(memmap_addr + EC_MEMMAP_HOST_CMD_FLAGS);
    }

    if (version & EC_HOST_CMD_FLAG_VERSION_3) {
        /* Protocol version 3 */
        ec_command_proto = 3;
    } else {
        debug_print(''EC doesn't support protocols we need.\n'');
        return STATUS_NOT_SUPPORTED;
    }

    return STATUS_SUCCESS;
}

/// Execute a command on the EC.
///
/// @param in [0] = version, [1] = command, [2] = outgoing length in bytes, [3] = incoming length in bytes, [4..38] = data
/// @param in_size Must be 4 + ceil(outgoing length / 8)
/// @param out [0] = number of received bytes or negative for error, [1..33] = data received
/// @param out_size Must be 1 + ceil(incoming length / 8)
/// @return An NTSTATUS
DEFINE_IOCTL(ioctl_ec_command) {
    if (in_size < 4)
        return STATUS_BUFFER_TOO_SMALL;
    if (out_size < 1)
        return STATUS_BUFFER_TOO_SMALL;

    new NTSTATUS:status;
    new result;
    new version = in[0];
    new command = in[1];
    /*
     * ec_out_* and ec_in_* are outgoing and incoming to the EC.
     * They are flipped from the in and out parameters to this function.
     */
    new ec_out_size = in[2] & 0xFF;
    new ec_in_size = in[3] & 0xFF;
    new ec_out_data[EC_LPC_HOST_PACKET_SIZE];
    new ec_in_data[EC_LPC_HOST_PACKET_SIZE];

    if (in_size < 4 + div_ceil(ec_out_size, 8))
        return STATUS_BUFFER_TOO_SMALL;
    if (out_size < 1 + div_ceil(ec_in_size, 8))
        return STATUS_BUFFER_TOO_SMALL;

    if (ec_out_size > EC_LPC_HOST_PACKET_SIZE - 1)
        return STATUS_INVALID_PARAMETER;
    if (ec_in_size > EC_LPC_HOST_PACKET_SIZE - 1)
        return STATUS_INVALID_PARAMETER;

    if (ec_command_proto == 3) {
        unpack_bytes_le(in, ec_out_data, ec_out_size, 4 * 8, 0);

        status = ec_command_lpc_3(command, version, ec_out_data, ec_out_size, ec_in_data, ec_in_size, result);
        if (!NT_SUCCESS(status))
            return status;

        out[0] = result;
        if (result >= 0)
            pack_bytes_le(ec_in_data, out, ec_in_size, 0, 8);
        return STATUS_SUCCESS;
    }

    return STATUS_NOT_SUPPORTED;
}

/// Read memory from the EC memory map.
/// @param in [0] = offset, [1] = bytes to read
/// @param in_size Must be 2
/// @param out [0..32] = data read from EC memory map
/// @param out_size Must be at least 1 and equal ceil(bytes / 8)
/// @return An NTSTATUS
DEFINE_IOCTL(ioctl_ec_readmem) {
    if (in_size < 2)
        return STATUS_BUFFER_TOO_SMALL;
    if (out_size < 1)
        return STATUS_BUFFER_TOO_SMALL;

    new NTSTATUS:status;
    new offset = in[0] & 0xFFFF;
    new bytes = in[1] & 0xFF;
    new out_data[EC_MEMMAP_SIZE];

    if (out_size < div_ceil(bytes, 8))
        return STATUS_BUFFER_TOO_SMALL;
    if (bytes > out_size * 8)
        return STATUS_BUFFER_TOO_SMALL;

    status = ec_readmem_lpc(offset, bytes, out_data);
    if (!NT_SUCCESS(status))
        return status;

    pack_bytes_le(out_data, out, bytes);

    return STATUS_SUCCESS;
}

NTSTATUS:main() {
    return comm_init_lpc();
}
