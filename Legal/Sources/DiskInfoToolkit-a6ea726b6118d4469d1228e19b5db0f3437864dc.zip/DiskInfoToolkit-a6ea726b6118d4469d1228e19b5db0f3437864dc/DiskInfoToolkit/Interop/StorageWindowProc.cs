﻿/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 *
 * Copyright (c) 2026 Florian K.
 */

using System.Runtime.InteropServices;

namespace DiskInfoToolkit.Interop
{
    [UnmanagedFunctionPointer(CallingConvention.Winapi)]
    public delegate IntPtr StorageWindowProc(IntPtr hWnd, uint msg, UIntPtr wParam, IntPtr lParam);
}
