﻿/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 *
 * Copyright (c) 2025 Florian K.
 */

using Avalonia.Data;
using Avalonia.Data.Converters;
using BlackSharp.UI.Avalonia.Converter;

namespace BlackSharp.UI.Avalonia.Data
{
    /// <summary>
    /// Binding which scales to given <see cref="Factor"/>.
    /// </summary>
    public class ScaleBinding : ReflectionBinding
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ScaleBinding"/> class.
        /// </summary>
        public ScaleBinding()
            : base()
        {
            base.Converter = _Converter;
            ConverterParameter = 1.0;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ScaleBinding"/> class.
        /// </summary>
        /// <param name="path">The binding path.</param>
        /// <param name="mode">The binding mode.</param>
        public ScaleBinding(string path, BindingMode mode = BindingMode.Default)
            : base(path)
        {
            Mode = mode;
            base.Converter = _Converter;
            ConverterParameter = 1.0;
        }

        #endregion

        #region Fields

        DoubleMultiplyConverter _Converter = new();

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the scale factor.
        /// </summary>
        public double Factor
        {
            get { return (double)ConverterParameter; }
            set
            {
                if (value <= 0)
                    throw new ArgumentOutOfRangeException($"{nameof(Factor)} must be greater than zero (received: {value}).");
                ConverterParameter = value;
            }
        }

        /// <inheritdoc cref="ReflectionBinding.Converter"/>
        public new IValueConverter Converter
        {
            get { return _Converter; }
            set
            {
                throw new InvalidOperationException($"Cannot set Converter on {nameof(ScaleBinding)}. The converter is built-in.");
            }
        }

        #endregion

        #region Public

        /// <summary>
        /// Provides this binding instance when the binding is used as an Avalonia XAML markup extension.
        /// </summary>
        /// <param name="serviceProvider">
        /// The XAML service provider supplied by Avalonia.<br/>
        /// This binding does not require it because all binding configuration is already stored on the instance.
        /// </param>
        /// <returns>
        /// The current <see cref="ScaleBinding"/> instance.
        /// </returns>
        public object ProvideValue(IServiceProvider serviceProvider)
        {
            return this;
        }

        #endregion
    }
}
