﻿/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 *
 * Copyright (c) 2025 Florian K.
 */

using System.Runtime.InteropServices;

namespace BlackSharp.Core.Interop.Windows.Structures
{
    [StructLayout(LayoutKind.Sequential)]
    internal struct Acl
    {
        byte AclRevision;
        byte Sbz1;
        short AclSize;
        short AceCount;
        short Sbz2;
    }
}
