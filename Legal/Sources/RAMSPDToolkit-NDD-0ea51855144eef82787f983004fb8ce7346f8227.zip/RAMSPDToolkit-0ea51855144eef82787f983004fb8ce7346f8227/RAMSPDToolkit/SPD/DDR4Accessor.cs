﻿/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 *
 * Copyright (c) 2025 Florian K.
 *
 * Code inspiration, improvements and fixes are from, but not limited to, following projects:
 * LibreHardwareMonitor; Linux Kernel; OpenRGB; WinRing0 (QCute)
 */

using BlackSharp.Core.BitOperations;
using BlackSharp.Core.Extensions;
using RAMSPDToolkit.I2CSMBus;
using RAMSPDToolkit.I2CSMBus.Interop.PawnIO;
using RAMSPDToolkit.I2CSMBus.Interop.Shared;
using RAMSPDToolkit.Logging;
using RAMSPDToolkit.SPD.Interfaces;
using RAMSPDToolkit.SPD.Interop;
using RAMSPDToolkit.SPD.Interop.Shared;
using RAMSPDToolkit.SPD.Timings;
using RAMSPDToolkit.Utilities;

namespace RAMSPDToolkit.SPD
{
    /// <summary>
    /// Accessor for DDR4 SPD.<br/>
    /// This works for Windows and Linux.
    /// </summary>
    /// <remarks>Please refer to JEDEC Standard for EE1004 and TSE2004av for property definitions.</remarks>
    public sealed class DDR4Accessor : DDR4AccessorBase, IThermalDataDDR4
    {
        #region Constructor

        public DDR4Accessor(SMBusInterface bus, byte address)
            : base(bus, (byte)(address - SPDConstants.SPD_BEGIN))
        {
            _Address = address;

            //Set thermal sensor address
            _ThermalSensorAddress = (byte)(0x18 | (address & 0x07));

            //Check for thermal sensor
            HasThermalSensor = ProbeThermalSensor();

            if (HasThermalSensor)
            {
                //We want these values to be read, just wait until SMBus is not busy
                ReadThermalSensorConfiguration(SPDConstants.SPD_CFG_RETRIES);
            }

            SDRAMTimings = new DDR4Timings(this);
        }

        #endregion

        #region Fields

        readonly byte _Address;
        readonly byte _ThermalSensorAddress;

        #endregion

        #region Properties

        public ushort ThermalSensorCapabilitiesRegister { get; private set; } = ushort.MaxValue;

        public ushort ThermalSensorConfigurationRegister { get; private set; } = ushort.MaxValue;

        public float ThermalSensorCriticalLimit { get; private set; } = float.NaN;

        public ushort ThermalSensorManufacturerID { get; private set; } = ushort.MaxValue;

        public ushort ThermalSensorDeviceID { get; private set; } = ushort.MaxValue;

        /// <inheritdoc cref="DDR4Timings"/>
        public DDR4Timings SDRAMTimings { get; private set; }

        #endregion

        #region Public

        /// <summary>
        /// Detects if a DDR4 RAM is available at specified address.
        /// </summary>
        /// <param name="bus">SMBus to check for RAM.</param>
        /// <param name="address">Address to check.</param>
        /// <returns>True if DDR4 is available at specified address; false otherwise.</returns>
        public static bool IsAvailable(SMBusInterface bus, byte address)
        {
            int value;

            //Select first page
            bus.i2c_smbus_write_byte_data(DDR4Constants.SPD_DDR4_ADDRESS_PAGE, 0x00, DDR4Constants.SPD_DDR4_EEPROM_PAGE_MASK);

            Thread.Sleep(SPDConstants.SPD_IO_DELAY);

            //Read memory type
            value = bus.i2c_smbus_read_byte_data(address, DDR4Constants.SPD_DDR4_MODULE_MEMORY_TYPE);

            //Check if memory type is DDR4
            return ((SPDMemoryType)value).Any(SPDMemoryType.SPD_DDR4_SDRAM,
                                              SPDMemoryType.SPD_DDR4E_SDRAM,
                                              SPDMemoryType.SPD_LPDDR4_SDRAM,
                                              SPDMemoryType.SPD_LPDDR4X_SDRAM);
        }

        #endregion

        #region DDR4Accessor

        public override byte At(ushort address)
        {
            //Ensure address is valid
            if (address >= DDR4Constants.SPD_DDR4_EEPROM_LENGTH)
            {
                return 0xFF;
            }

            //Switch to the page containing address
            SetPage((byte)(address >> DDR4Constants.SPD_DDR4_EEPROM_PAGE_SHIFT));

            //Calculate offset
            byte offset = (byte)(address & DDR4Constants.SPD_DDR4_EEPROM_PAGE_MASK);

            //Read value at address
            RetryReadByteData(_Bus, _Address, offset, SPDConstants.SPD_DATA_RETRIES, out var value);

            Thread.Sleep(SPDConstants.SPD_IO_DELAY);

            //Return value
            return value;
        }

        public override byte[] At(ushort address, byte length)
        {
            //Ensure address is valid
            if (address >= DDR4Constants.SPD_DDR4_EEPROM_LENGTH)
            {
                return [];
            }

            //Switch to the page containing address
            SetPage((byte)(address >> DDR4Constants.SPD_DDR4_EEPROM_PAGE_SHIFT));

            //Calculate offset
            byte offset = (byte)(address & DDR4Constants.SPD_DDR4_EEPROM_PAGE_MASK);

            //Read values at address
            RetryReadI2CBlockData(_Bus, _Address, offset, length, SPDConstants.SPD_DATA_RETRIES, out var value);

            Thread.Sleep(SPDConstants.SPD_IO_DELAY);

            //Return value
            return value;
        }

        public override bool UpdateTemperature()
        {
            //Set page to 0 to read volatile data
            SetPage(0);

            var status = RetryReadWordDataSwapped(_Bus, _ThermalSensorAddress, DDR4Constants.SPD_DDR4_TEMPERATURE_ADDRESS, SPDConstants.SPD_TS_RETRIES, out ushort temp);

            temp = RawTemperatureAdjust(temp);

            if (status >= 0)
            {
                Temperature = SPDTemperatureConverter.CheckAndConvertTemperature(temp);
            }
            else
            {
                LogSimple.LogTrace($"Temperature read failed with status {status}.");
            }

            return status >= 0;
        }

        #endregion

        #region Private

        bool ProbeThermalSensor()
        {
            //Set page to 0 in order to read
            SetPage(0);

            var status = _Bus.i2c_smbus_read_byte_data(_Address, DDR4Constants.SPD_DDR4_THERMAL_SENSOR_BYTE);

            if (status < 0)
            {
                LogSimple.LogTrace($"Failed to read {nameof(DDR4Constants.SPD_DDR4_THERMAL_SENSOR_BYTE)}.");
            }
            else
            {
                //Check if thermal sensor bit is set
                if (BitHandler.IsBitSet((byte)status, DDR4Constants.SPD_DDR4_THERMAL_SENSOR_BIT))
                {
                    LogSimple.LogTrace($"0x{_Address:X2} has {nameof(DDR4Constants.SPD_DDR4_THERMAL_SENSOR_BIT)} set.");
                    return true;
                }
                else
                {
                    LogSimple.LogTrace($"0x{_Address:X2} does not have {nameof(DDR4Constants.SPD_DDR4_THERMAL_SENSOR_BIT)} set.");
                    LogSimple.LogTrace($"Checking another way if thermal sensor is present.");

                    //Fallback: do a quick read to the thermal sensors address to check if it is available
                    status = _Bus.i2c_smbus_write_quick(_ThermalSensorAddress, 0x00);

                    if (status < 0)
                    {
                        LogSimple.LogTrace($"0x{_Address:X2} Thermal sensor address did not respond or quick was unsupported.");

                        //Fallback: probe a mandatory TSOD register.
                        status = _Bus.i2c_smbus_read_word_data(_ThermalSensorAddress, DDR4Constants.SPD_DDR4_THERMAL_SENSOR_CAPABILITIES_REGISTER);

                        if (status < 0)
                        {
                            LogSimple.LogTrace($"0x{_Address:X2} Thermal sensor not found.");
                            return false;
                        }
                        else
                        {
                            LogSimple.LogTrace($"0x{_Address:X2} Unregistered thermal sensor found.");

                            return true;
                        }
                    }
                    else
                    {
                        LogSimple.LogTrace($"0x{_Address:X2} Unregistered thermal sensor found.");

                        return true;
                    }
                }
            }

            return false;
        }

        void ReadThermalSensorConfiguration(int retries)
        {
            //Set page to 0
            SetPage(0);

            ushort wordTemp;

            //Sensor Capabilities
            var status = RetryReadWordDataSwapped(_Bus, _ThermalSensorAddress, DDR4Constants.SPD_DDR4_THERMAL_SENSOR_CAPABILITIES_REGISTER, retries, out wordTemp);
            if (status < 0)
            {
                LogSimple.LogTrace($"Reading {nameof(DDR4Constants.SPD_DDR4_THERMAL_SENSOR_CAPABILITIES_REGISTER)} failed with status {status}.");
            }
            else
            {
                ThermalSensorCapabilitiesRegister = wordTemp;

                TemperatureResolution = 0.5f / (1 << ((ThermalSensorCapabilitiesRegister & 0x18) >> 3));

                LogSimple.LogTrace($"{nameof(ThermalSensorCapabilitiesRegister)} = {ThermalSensorCapabilitiesRegister}.");
            }

            //Sensor Configuration
            status = RetryReadWordDataSwapped(_Bus, _ThermalSensorAddress, DDR4Constants.SPD_DDR4_THERMAL_SENSOR_CONFIGURATION_REGISTER, retries, out wordTemp);
            if (status < 0)
            {
                LogSimple.LogTrace($"Reading {nameof(DDR4Constants.SPD_DDR4_THERMAL_SENSOR_CONFIGURATION_REGISTER)} failed with status {status}.");
            }
            else
            {
                ThermalSensorConfigurationRegister = wordTemp;

                LogSimple.LogTrace($"{nameof(ThermalSensorConfigurationRegister)} = {ThermalSensorConfigurationRegister}.");
            }

            //Sensor High Limit
            status = RetryReadWordDataSwapped(_Bus, _ThermalSensorAddress, DDR4Constants.SPD_DDR4_THERMAL_SENSOR_HIGH_LIMIT, retries, out wordTemp);
            if (status < 0)
            {
                LogSimple.LogTrace($"Reading {nameof(DDR4Constants.SPD_DDR4_THERMAL_SENSOR_HIGH_LIMIT)} failed with status {status}.");
            }
            else
            {
                wordTemp = RawTemperatureAdjust(wordTemp);

                ThermalSensorHighLimit = SPDTemperatureConverter.CheckAndConvertTemperature(wordTemp);

                LogSimple.LogTrace($"{nameof(ThermalSensorHighLimit)} = {ThermalSensorHighLimit}.");
            }

            //Sensor Low Limit
            status = RetryReadWordDataSwapped(_Bus, _ThermalSensorAddress, DDR4Constants.SPD_DDR4_THERMAL_SENSOR_LOW_LIMIT, retries, out wordTemp);
            if (status < 0)
            {
                LogSimple.LogTrace($"Reading {nameof(DDR4Constants.SPD_DDR4_THERMAL_SENSOR_LOW_LIMIT)} failed with status {status}.");
            }
            else
            {
                wordTemp = RawTemperatureAdjust(wordTemp);

                ThermalSensorLowLimit = SPDTemperatureConverter.CheckAndConvertTemperature(wordTemp);

                LogSimple.LogTrace($"{nameof(ThermalSensorLowLimit)} = {ThermalSensorLowLimit}.");
            }

            //Sensor Critical Limit
            status = RetryReadWordDataSwapped(_Bus, _ThermalSensorAddress, DDR4Constants.SPD_DDR4_THERMAL_SENSOR_CRIT_LIMIT, retries, out wordTemp);
            if (status < 0)
            {
                LogSimple.LogTrace($"Reading {nameof(DDR4Constants.SPD_DDR4_THERMAL_SENSOR_CRIT_LIMIT)} failed with status {status}.");
            }
            else
            {
                wordTemp = RawTemperatureAdjust(wordTemp);

                ThermalSensorCriticalLimit = SPDTemperatureConverter.CheckAndConvertTemperature(wordTemp);

                LogSimple.LogTrace($"{nameof(ThermalSensorCriticalLimit)} = {ThermalSensorCriticalLimit}.");
            }

            //Sensor Manufacturer
            status = RetryReadWordDataSwapped(_Bus, _ThermalSensorAddress, DDR4Constants.SPD_DDR4_THERMAL_SENSOR_MANUFACTURER, retries, out wordTemp);
            if (status < 0)
            {
                LogSimple.LogTrace($"Reading {nameof(DDR4Constants.SPD_DDR4_THERMAL_SENSOR_MANUFACTURER)} failed with status {status}.");
            }
            else
            {
                ThermalSensorManufacturerID = wordTemp;

                LogSimple.LogTrace($"{nameof(ThermalSensorManufacturerID)} = {ThermalSensorManufacturerID}.");
            }

            //Sensor DeviceID / Revision Register
            status = RetryReadWordDataSwapped(_Bus, _ThermalSensorAddress, DDR4Constants.SPD_DDR4_THERMAL_SENSOR_DEVICEID, retries, out wordTemp);
            if (status < 0)
            {
                LogSimple.LogTrace($"Reading {nameof(DDR4Constants.SPD_DDR4_THERMAL_SENSOR_DEVICEID)} failed with status {status}.");
            }
            else
            {
                ThermalSensorDeviceID = wordTemp;

                LogSimple.LogTrace($"{nameof(ThermalSensorDeviceID)} = {ThermalSensorDeviceID}.");
            }
        }

        #endregion
    }
}
