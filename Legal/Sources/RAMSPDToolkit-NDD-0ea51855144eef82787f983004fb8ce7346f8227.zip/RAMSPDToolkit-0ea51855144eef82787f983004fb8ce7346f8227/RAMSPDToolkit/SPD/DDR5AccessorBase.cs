﻿/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 *
 * Copyright (c) 2025 Florian K.
 *
 * Code inspiration, improvements and fixes are from, but not limited to, following projects:
 * LibreHardwareMonitor; Linux Kernel; OpenRGB; WinRing0 (QCute)
 */

using BlackSharp.Core.BitOperations;
using BlackSharp.Core.ByteOperations;
using BlackSharp.Core.Globalization;
using RAMSPDToolkit.I2CSMBus;
using RAMSPDToolkit.I2CSMBus.Interop;
using RAMSPDToolkit.Logging;
using RAMSPDToolkit.SPD.Enums;
using RAMSPDToolkit.SPD.Interfaces;
using RAMSPDToolkit.SPD.Interop;
using RAMSPDToolkit.SPD.Interop.Shared;
using RAMSPDToolkit.SPD.Mappings;
using System.Text;

using OS = BlackSharp.Core.Platform.OperatingSystem;

namespace RAMSPDToolkit.SPD
{
    /// <summary>
    /// Base class for DDR5 SPD accessors.
    /// </summary>
    public abstract class DDR5AccessorBase : SPDAccessor, IThermalSensor
    {
        #region Constructor

        protected DDR5AccessorBase(SMBusInterface bus, byte address)
            : base(bus, (byte)(address - SPDConstants.SPD_BEGIN))
        {
            _Address = address;

            ReadWriteRecoveryTime(SPDConstants.SPD_CFG_RETRIES);

            var page = GetPage();

            if (PageMappingDDR5.PageDataMapping.TryGetValue(page, out var pageData))
            {
                _PageData = pageData;
            }
        }

        #endregion

        #region Fields

        protected readonly byte _Address;

        #endregion

        #region Properties

        public bool  HasThermalSensor       { get; protected set; }
        public float Temperature            { get; protected set; } = float.NaN;
        public float TemperatureResolution  { get; protected set; } = float.NaN;
        public float ThermalSensorLowLimit  { get; protected set; } = float.NaN;
        public float ThermalSensorHighLimit { get; protected set; } = float.NaN;

        /// <summary>
        /// Device write recovery time in milliseconds.
        /// </summary>
        public decimal WriteRecoveryTime { get; private set; } = decimal.Zero;

        #endregion

        #region SPDAccessor

        public override byte SPDRevision()
        {
            return At(DDR5Constants.SPD_DDR5_MODULE_SPD_REVISION);
        }

        public override SPDMemoryType MemoryType()
        {
            return (SPDMemoryType)At(DDR5Constants.SPD_DDR5_MODULE_MEMORY_TYPE);
        }

        public override float GetCapacity()
        {
            var firstDensityAndPackage  = At(DDR5Constants.SPD_DDR5_MODULE_FIRST_DENSITY_PACKAGE );
            var secondDensityAndPackage = At(DDR5Constants.SPD_DDR5_MODULE_SECOND_DENSITY_PACKAGE);
            var dimmAttributes          = At(DDR5Constants.SPD_DDR5_MODULE_DIMM_ATTRIBUTES       );
            var organization            = At(DDR5Constants.SPD_DDR5_MODULE_ORGANIZATION          );

            var firstDensityPerDie  = BitHandler.GetBits(firstDensityAndPackage , 0, 4);
            var firstDiePerPackage  = BitHandler.GetBits(firstDensityAndPackage , 5, 7);
            var secondDensityPerDie = BitHandler.GetBits(secondDensityAndPackage, 0, 4);
            var secondDiePerPackage = BitHandler.GetBits(secondDensityAndPackage, 5, 7);

            var rowsOfDRAMs               = BitHandler.ExtractBits(dimmAttributes, 0, 1, 3);
            var operatingTemperatureRange = BitHandler.GetBits    (dimmAttributes, 4, 7);

            var rankMix      = BitHandler.GetBits(organization, 6, 6);
            var packageRanks = BitHandler.GetBits(organization, 3, 5);

            if (rankMix == DDR5Constants.SPD_DDR5_RANKMIX_SYMMETRICAL)
            {
                return GetDies(firstDiePerPackage)
                     * GetDensityPerDie(firstDensityPerDie)
                     * GetRows(rowsOfDRAMs)
                     * GetRanks(packageRanks);
            }
            else if (rankMix == DDR5Constants.SPD_DDR5_RANKMIX_ASYMMETRICAL)
            {
                return
                (
                    GetDies(firstDiePerPackage ) * GetDensityPerDie(firstDensityPerDie )
                  + GetDies(secondDiePerPackage) * GetDensityPerDie(secondDensityPerDie)
                )
                * GetRows(rowsOfDRAMs)
                * GetRanks(packageRanks);
            }

            throw new Exception($"{nameof(DDR5Constants.SPD_DDR5_MODULE_ORGANIZATION)} {nameof(rankMix)} is invalid.");
        }

        public override byte ModuleManufacturerContinuationCode()
        {
            return BitHandler.UnsetBit(At(DDR5Constants.SPD_DDR5_MODULE_MANUFACTURER_CONTINUATION_CODE), DDR5Constants.SPD_DDR5_MANUFACTURER_CONTINUATION_CODE_ODD_PARITY_BIT);
        }

        public override byte ModuleManufacturerIDCode()
        {
            return At(DDR5Constants.SPD_DDR5_MODULE_MANUFACTURER_ID_CODE);
        }

        public override byte ModuleManufacturingLocation()
        {
            return At(DDR5Constants.SPD_DDR5_MODULE_MANUFACTURING_LOCATION);
        }

        public override DateTime? ModuleManufacturingDate()
        {
            var year = At(DDR5Constants.SPD_DDR5_MODULE_MANUFACTURING_DATE_BEGIN);
            var week = At(DDR5Constants.SPD_DDR5_MODULE_MANUFACTURING_DATE_END);

            //Sometimes there is no data
            if (year == 0 && week == 0)
            {
                return null;
            }

            return ISOWeek.ToDateTime(BinaryHandler.NormalizeBcd(year) + 2000, BinaryHandler.NormalizeBcd(week));
        }

        public override string ModuleSerialNumber()
        {
            var sb = new StringBuilder();

            var serialNumberBytes = At(DDR5Constants.SPD_DDR5_MODULE_SERIAL_NUMBER_BEGIN, DDR5Constants.SPD_DDR5_MODULE_SERIAL_NUMBER_END - DDR5Constants.SPD_DDR5_MODULE_SERIAL_NUMBER_BEGIN + 1);

            foreach (var b in serialNumberBytes)
            {
                sb.Append($"{b:X2}");
            }

            return sb.ToString();
        }

        public override string ModulePartNumber()
        {
            var partNumberBytes = At(DDR5Constants.SPD_DDR5_MODULE_PART_NUMBER_BEGIN, DDR5Constants.SPD_DDR5_MODULE_PART_NUMBER_END - DDR5Constants.SPD_DDR5_MODULE_PART_NUMBER_BEGIN + 1);

            var validBytes = partNumberBytes
                .Where(b => b != DDR5Constants.SPD_DDR5_MODULE_PART_NUMBER_UNUSED)
                .ToArray();

            //Some manufacturers include (multiple) zero terminators
            return Encoding.ASCII.GetString(validBytes).Trim('\0');
        }

        public override byte ModuleRevisionCode()
        {
            return At(DDR5Constants.SPD_DDR5_MODULE_REVISION_CODE);
        }

        public override byte DRAMManufacturerContinuationCode()
        {
            return BitHandler.UnsetBit(At(DDR5Constants.SPD_DDR5_DRAM_MANUFACTURER_CONTINUATION_CODE), DDR5Constants.SPD_DDR5_MANUFACTURER_CONTINUATION_CODE_ODD_PARITY_BIT);
        }

        public override byte DRAMManufacturerIDCode()
        {
            return At(DDR5Constants.SPD_DDR5_DRAM_MANUFACTURER_ID_CODE);
        }

        public override byte ManufacturerSpecificData(ushort index)
        {
            const int manufacturerSpecificDataMaxLength = DDR5Constants.SPD_DDR5_MANUFACTURER_SPECIFIC_DATA_END
                                                        - DDR5Constants.SPD_DDR5_MANUFACTURER_SPECIFIC_DATA_BEGIN;

            if (index > manufacturerSpecificDataMaxLength)
            {
                return 0;
            }

            return At((ushort)(DDR5Constants.SPD_DDR5_MANUFACTURER_SPECIFIC_DATA_BEGIN + index));
        }

        public override bool ChangePage(PageData pageData)
        {
            //Loop through page mapping and get proper page for requested data
            foreach (var item in PageMappingDDR5.PageDataMapping)
            {
                if (item.Value.HasFlag(pageData))
                {
                    SetPage(item.Key);

                    return PageData.HasFlag(pageData);
                }
            }

            return false;
        }

        protected override byte GetPage()
        {
            //Read the current page
            var status = _Bus.i2c_smbus_read_byte_data(_Address, DDR5Constants.SPD_DDR5_MREG_VIRTUAL_PAGE);

            if (status < 0)
            {
                return byte.MaxValue;
            }

            //Return the first 3 bits of the MR11 register
            return (byte)(status & 0x07);
        }

        protected override void SetPage(byte page)
        {
            if (GetPage() == page)
            {
                return;
            }

            int status;

            //Linux Kernel (i2c-i801.c) supports PROC_CALL, but unfortunately only with I2C_SMBUS_WRITE
            //while we would require a I2C_SMBUS_READ instead.
            //So we currently cannot go around the write protection for page change on Linux.
            if (_Bus.HasSPDWriteProtection && OS.IsLinux())
            {
                //No page change for write protection + Linux system
                return;
            }
            //Write protection is active (Intel) - change page via PROC_CALL
            else if (_Bus.HasSPDWriteProtection)
            {
                status = _Bus.i2c_smbus_proc_call(_Address, I2CConstants.I2C_SMBUS_READ, DDR5Constants.SPD_DDR5_MREG_VIRTUAL_PAGE, page);
            }
            else //No write protection, change it normally
            {
                status = _Bus.i2c_smbus_write_byte_data(_Address, DDR5Constants.SPD_DDR5_MREG_VIRTUAL_PAGE, page);
            }

            //Page change OK
            if (status >= 0)
            {
                if (PageMappingDDR5.PageDataMapping.TryGetValue(page, out var pageData))
                {
                    _PageData = pageData;
                }
            }

            //Use write recovery time or default
            var sleepTime = WriteRecoveryTime > 0 ? WriteRecoveryTime : SPDConstants.SPD_IO_DELAY;

            Thread.Sleep(TimeSpan.FromMilliseconds((double)sleepTime));
        }

        #endregion

        #region IThermalSensor

        public abstract bool UpdateTemperature();

        #endregion

        #region Private

        void ReadWriteRecoveryTime(int retries)
        {
            //Write Recovery Time
            var status = RetryReadByteData(_Bus, _Address, DDR5Constants.SPD_DDR5_WRITE_RECOVERY_TIME, retries, out var byteTemp);
            if (status < 0)
            {
                LogSimple.LogTrace($"Reading {nameof(DDR5Constants.SPD_DDR5_WRITE_RECOVERY_TIME)} failed with status {status}.");
            }
            else
            {
                var timeUnit = BitHandler.GetBits(byteTemp, 0, 1);
                var recUnit  = BitHandler.GetBits(byteTemp, 4, 7);

                decimal recoveryTime = 0;

                switch (recUnit)
                {
                    case byte x when (x <= 10 && x >= 0):
                        recoveryTime = x;
                        break;
                    case 0b1011:
                        recoveryTime = 50;
                        break;
                    case 0b1100:
                        recoveryTime = 100;
                        break;
                    case 0b1101:
                        recoveryTime = 200;
                        break;
                    case 0b1110:
                        recoveryTime = 500;
                        break;
                }

                switch (timeUnit)
                {
                    case 0b00: //Nanoseconds
                        recoveryTime = recoveryTime == 0 ? 0 : recoveryTime / 1_000_000M;
                        break;
                    case 0b01: //Microseconds
                        recoveryTime = recoveryTime == 0 ? 0 : recoveryTime / 1000M;
                        break;
                    case 0b10: //Milliseconds
                        //recoveryTime = recoveryTime;
                        break;
                }

                WriteRecoveryTime = recoveryTime;

                LogSimple.LogTrace($"{nameof(WriteRecoveryTime)} = {WriteRecoveryTime} ms (Raw = {byteTemp}).");
            }
        }

        int GetDies(int rawValue)
        {
            int dies = 1;

            switch (rawValue)
            {
                case 0b000:
                    dies = 1;
                    break;
                case 0b001:
                case 0b010:
                    dies = 2;
                    break;
                case 0b011:
                    dies = 4;
                    break;
                case 0b100:
                    dies = 8;
                    break;
                case 0b101:
                    dies = 16;
                    break;
            }

            return dies;
        }

        float GetDensityPerDie(int rawValue)
        {
            float gb = 0;

            switch (rawValue)
            {
                case 0b00001:
                    gb = 4;
                    break;
                case 0b00010:
                    gb = 8;
                    break;
                case 0b00011:
                    gb = 12;
                    break;
                case 0b00100:
                    gb = 16;
                    break;
                case 0b00101:
                    gb = 24;
                    break;
                case 0b00110:
                    gb = 32;
                    break;
                case 0b00111:
                    gb = 48;
                    break;
                case 0b01000:
                    gb = 64;
                    break;
            }

            return gb;
        }

        int GetRanks(int rawValue)
        {
            byte ranks = 0;

            switch (rawValue)
            {
                case 0b000:
                    ranks = 1;
                    break;
                case 0b001:
                    ranks = 2;
                    break;
                case 0b010:
                    ranks = 3;
                    break;
                case 0b011:
                    ranks = 4;
                    break;
                case 0b100:
                    ranks = 5;
                    break;
                case 0b101:
                    ranks = 6;
                    break;
                case 0b110:
                    ranks = 7;
                    break;
                case 0b111:
                    ranks = 8;
                    break;
            }

            return ranks;
        }

        int GetRows(int rawValue)
        {
            byte rows = 1;

            switch (rawValue)
            {
                case 0b001:
                    rows = 1;
                    break;
                case 0b010:
                    rows = 2;
                    break;
                case 0b011:
                    rows = 4;
                    break;
                case 0b100:
                    rows = 3;
                    break;
            }

            return rows;
        }

        #endregion
    }
}
